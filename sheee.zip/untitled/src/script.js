// Brillo al tocar frases

document.querySelectorAll(".planet").forEach(planet => {

  planet.addEventListener("click", () => {

    planet.classList.toggle("active");

  });

});

// Corazones automáticos

setInterval(() => {

  const heart = document.createElement("div");

  heart.classList.add("heart");

  heart.innerHTML = "💖";

  heart.style.left = Math.random() * 100 + "vw";

  document.body.appendChild(heart);

  setTimeout(() => heart.remove(), 6000);

}, 800);